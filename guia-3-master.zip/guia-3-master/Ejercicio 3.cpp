#include <iostream>
#include <math.h>
using namespace std;
int  main() {
  float a, b, c, x;
   cout<<"Ingrese un valor para a: " ;
   cin>>a;
   cout<<"ingrese un valor para b: " ;
   cin>>b;
   cout<<"Ingrese un valor para c: " ;
   cin>>c;

   x  = ( a + b + c)/3;

   cout<<"El promedio es: "<<x;
     
     return 0;
}
